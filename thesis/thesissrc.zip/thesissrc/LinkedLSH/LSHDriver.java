import org.apache.commons.cli.*;
import java.io.*;
import java.util.*;

class LSHDriver 
{
	public static void main(String[] args) 
	{
		Options options = new Options();
		options.addOption("i", true, "Input points");
		options.addOption("q", true, "Query points");
		options.addOption("L", true, "L param for LSH");
		options.addOption("k", true, "k param for LSH");
		options.addOption("h", false, "Show this");
		options.addOption("result", false, "Show result");
		options.addOption("time", false, "Show time");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}
		
		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java LSHDriver", options );
			System.exit(0);
		}

		Integer L = 2, k = 2;

		try {
			L = Integer.valueOf(cmd.getOptionValue("L"));
			k = Integer.valueOf(cmd.getOptionValue("k"));
		} catch(Exception e) {}

		
		String inputFileName = cmd.getOptionValue("i");
		String queryFileName = cmd.getOptionValue("q");
		
		InputReader ir = new InputReader();
		ArrayList<double[]> inputList = ir.ftm(inputFileName);
		ArrayList<double[]> queryList = ir.ftm(queryFileName);

		System.err.println("Building...");
		LSH lsh = new LSH(L, k, 4.0, ir.dimensions, inputList.size());
		
		lsh.build(inputList);

		System.err.println("Querying...");
		for(double[] q : queryList) {
			Bucket res = lsh.get(q);
			if(cmd.hasOption("result")) {
				System.out.println(res);
			}
		}
		
		if(cmd.hasOption("time")) {
			//System.out.println(ir.dimensions + "\t" + (double)lsh.c/queryList.size() + "\t" + lsh.time/queryList.size());
			System.out.println((double)lsh.c/queryList.size() + "\t" + lsh.time/queryList.size());
		}
	}

	/**
	 * A Double[] toString method.
	 */
	private static String printDoubleArray(Double[] q) {
		String out = "";
		for(int i = 0; i < q.length-1; i++) out += q[i] + "\t";
		out += q[q.length-1];

		return out;
	}
}
