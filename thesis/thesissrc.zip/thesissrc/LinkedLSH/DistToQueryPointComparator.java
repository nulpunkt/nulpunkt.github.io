import java.util.*;

public class DistToQueryPointComparator implements Comparator<Bucket>
{
	public int compare(Bucket b1, Bucket b2)
	{
		if(b1.dist < b2.dist) return -1;
		if(b1.dist > b2.dist) return 1;
		return 0;
	}
}
