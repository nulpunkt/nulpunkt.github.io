import java.io.*;
import java.util.*;

/**
 * Reads input file into array.
 */
public class InputReader 
{
	boolean verbose;
	int points, dimensions;

	public InputReader()
	{
		verbose = false;
	}

	/**
	 * "File to matrix", read a file, and make an array of vectors (simple arrays)
	 */
	public ArrayList<double[]> ftm(String file)
	{
		ArrayList<double[]> result = new ArrayList<double[]>();
		try { 
			DataInputStream in = new DataInputStream(
										new BufferedInputStream(
											new FileInputStream(file)
											)
									);
			this.points = in.readInt();
			this.dimensions = in.readInt();
			System.err.println("points: " + points + ", dimensions: " + dimensions);
			double[] a;
			for(int i = 0; i < points; i++) {
				a = new double[dimensions];
				for(int d = 0; d < dimensions; d++) {
					a[d] = in.readDouble();
				}
				result.add(a);
			} 
			in.close(); 
		} catch (Exception e) {
			System.err.println("InputReader: " + e);
		} 

		return result;
	}
}
