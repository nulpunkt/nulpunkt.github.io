import java.util.*;

public class NearNeighbor
{

	int k, tableSize, d;
	double w;

	double[][] a;
	double[] b;

	HashMap<Integer, Bucket> buckets;

	Random rand;

	boolean v;

	/**
	 * @param k Number of internal hash fkt
	 * @param w With of buck on the real line (RandomProjection)
	 * @param d #dimensions
	 */
	public NearNeighbor (int k, double w, int d, Random r)
	{
		this.k = k;
		this.w = w;
		this.d = d;
		this.rand = r;

		buckets = new HashMap<Integer, Bucket>();


		this.v = false;

		/* First initialize the a[k][d] and b[k] arrays, for the h hashes
		 * (s-stability)
		 */
		a = new double[k][d];
		b = new double[k];

		for(int i = 0; i < k; i++) {
			b[i] = rand.nextDouble() * w;

			for(int j = 0; j < d; j++) {
				a[i][j] = rand.nextGaussian();
			}
		}
	}

	/**
	 * From a query point q, return the first bucket matching
	 * with a good hash
	 */
	public Bucket get(double[] q) {

		return buckets.get(hash(q));
	}

	/**
	 * Puts a points p, with index i, in the structure.
	 */
	public void put(ArrayList<double[]> input)
	{
		int n = input.size();
		for(int i = 0; i < n; i++) {
			double[] p = input.get(i);
			int hash = hash(p);

			Bucket b = new Bucket(i);
			b.next = buckets.get(hash);

			buckets.put(hash, b);
		}
	}
	
	/**
	 * Hashes a d-dim vector to an int.
	 * This is the bucket in the hash table.
	 */
	public int hash(double[] p)
	{
		int[] h = new int[k];
		double aDotP;

		for(int i = 0; i < k; i++) {
			aDotP = 0.0;
			for(int j = 0; j < d; j++) aDotP += a[i][j]*p[j];

			h[i] = (int)Math.floor((aDotP+b[i])/w);

		}

		return Arrays.hashCode(h);
	}

	/**
	 * Makes the dot product between a radom vector a[i]
	 * and the given vector, implmenting a projection.
	 * @param p d-dim vector
	 * @return The projection
	 */
	public double dot(double[] a, double[] p)
	{
		double sum = 0.0;
		for(int i = 0; i < d; i++) {
			sum += (a[i]*p[i]);
		}

		return sum;
	}
}
