public class Bucket
{
	public int index;
	public Bucket next;
	public double dist;

	public Bucket(int i)
	{
		this.index = i;
	}

	public String toString()
	{
		return ""+index+"\tDistance:"+dist;
	}
}
