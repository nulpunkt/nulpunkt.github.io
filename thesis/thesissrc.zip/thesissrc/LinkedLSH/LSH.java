import java.util.*;
public class LSH
{
	NearNeighbor[] nn;
	int L, points, d, c;
	ArrayList<double[]> input;
	double time;

	public LSH(int L, int k, double w, int d, int points)
	{
		this.L = L;
		this.d = d;
		this.points = points;
		this.c = 0;
		this.time = 0.0;

		this.nn = new NearNeighbor[L];

		Random r = new Random(42);
		for(int i = 0; i < L; i++) {
			nn[i] = new NearNeighbor(k, w, d, r);
		}
	}

	public void build(ArrayList<double[]> input)
	{
		this.input = input;
		for(int j = 0; j < L; j++) {
			System.err.println(" - L: " + j);
			nn[j].put(input);
		}
	}

	/**
	 * Given a query point q and a number n, return n 
	 * near neighbors to q.
	 */
	public ArrayList<Bucket> getCandidates(double[] q)
	{
		ArrayList<Bucket> candidates = new ArrayList<Bucket>();
		BitSet unique = new BitSet(points);
		int total = 0;
		Dist dist = new Dist(d);

		long startTime, endTime;
		startTime = System.nanoTime();
		/* Search the structures */
		for(int i = 0; i < L; i++) {
			this.nn[i].v = true;
			Bucket b = nn[i].get(q);
			while(b != null) {
				if(!unique.get(b.index)) {
					b.dist = dist.euclidian(q, input.get(b.index));
					candidates.add(b);
					unique.set(b.index);
				}
				b = b.next;
				total++;
			}
		}
		DistToQueryPointComparator comp = new DistToQueryPointComparator();
		Collections.sort(candidates, comp);
		endTime = System.nanoTime();
		c += candidates.size();

		System.out.println("Found " + candidates.size() + " (" + total + ") candidates in time " + ((double)(endTime-startTime)/1000000000));

		return candidates;
	}
	
	/**
	 * Given a query point q and a number n, return n 
	 * near neighbors to q.
	 */
	public Bucket get(double[] q)
	{
		BitSet unique = new BitSet(points);
		int total = 0;
		Bucket res = null;
		Dist dist = new Dist(d);
		double tmp = Double.MAX_VALUE;

		long startTime, endTime;
		startTime = System.nanoTime();
		/* Search the structures */
		for(int i = 0; i < L; i++) {
			this.nn[i].v = false;
			Bucket b = nn[i].get(q);
			while(b != null) {
				if(!unique.get(b.index)) {
					b.dist = dist.euclidian(q, input.get(b.index));
					if(b.dist < tmp) {
						tmp = b.dist;
						res = b;
					}
					unique.set(b.index);
					c++;
				}
				b = b.next;
				total++;
			}
		}
		endTime = System.nanoTime();
		time += ((double)(endTime-startTime)/1000000000);

		//System.out.println("Found " + candidates.size() + " (" + total + ") candidates in time " + ((double)(endTime-startTime)/1000000000));

		return res;
	}
}
