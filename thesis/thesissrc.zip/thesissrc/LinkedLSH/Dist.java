/**
 * Implements the distance messures used in the algorithms
 */
public class Dist {

	int d;

	public Dist(int d)
	{
		this.d = d;
	}

	/**
	 * The euclidian distance.
	 * Takes 2 vectores and returns the distance between them
	 */
	public double euclidian (double[] v1, double[] v2)
	{
		double sum = 0;
		for(int i = 0; i < this.d; i++) {
			sum += Math.pow(v1[i] - v2[i], 2);
		}

		return Math.sqrt(sum);
	}

	/**
	 * The squared euclidian distance
	 */
	public double euclidianP (double[] v1, double[] v2)
	{
		double sum = 0;
		for(int i = 0; i < this.d; i++) {
			sum += Math.pow(v1[i] - v2[i], 2);
		}

		return sum;
	}
}
