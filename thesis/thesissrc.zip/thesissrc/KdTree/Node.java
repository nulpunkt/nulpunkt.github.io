/**
 * Implements a node in the KdTree.
 */
public class Node {
	int axis;
	double[] point;
	boolean leaf;
	Node left, right;
	int seen;

	/**
	 * Create a node that splites the plan on the a'th axis according to point p
	 * @param a Axis
	 * @param p Point
	 */
	public Node(int a, double[] p)
	{
		axis = a;
		point = p;
		seen = 0;
	}

	/**
	 * Set the right child
	 */
	public void setRightChild(Node c)
	{
		this.right = c;
	}

	/**
	 * Set Left child
	 */
	public void setLeftChild(Node c)
	{
		this.left = c;
	}
}
