#!/bin/bash
for i in `seq 2 7 1000`; do
	java -Xms512m -Xmx8000m BenchmarkApprox -d $i $@
done 
