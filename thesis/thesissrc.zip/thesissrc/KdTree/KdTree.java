import java.util.*;

/**
 * Implements a naiv KdTree
 */
public class KdTree 
{
	public ArrayList<double[]> inputList;
	public ArrayList<ArrayList<double[]>> sortedInput;
	int d, nodesSeen, maxNodes;
	RandomizedMedian rm;
	SortMedian sm;
	Dist dist;
	boolean backtracking;
	
	/**
	 * The KdTree contructor
	 * @param backtracking used to (en|dis)able backtracking in the quering
	 */
	public KdTree(boolean backtracking)
	{
		this.backtracking = backtracking;
	}

	/**
	 * Given a number of dimensions an a list of vectors build a Tree
	 * @param d Number of dimensions
	 * @param input List of points
	 * @return The root node of the KdTree
	 */
	public Node build(int d, ArrayList<double[]> input) 
	{
		inputList = input;
		this.d = d;
		rm = new RandomizedMedian();
		sm = new SortMedian();

		Node root = rBuild(0, input);
		return root;
	}

	public int depth(Node n)
	{
		if(n == null) return 0;
		else return Math.max(depth(n.left), depth(n.right))+1;
	}
	
	public int size(Node n)
	{
		if(n == null) return 0;
		else return (size(n.left) + size(n.right) + 1);
	}

	/**
	 * Recursivly builds the tree
	 * @param depth How deep in the tree are we
	 * @param input The subtree to be build
	 * @return Root node of the subtree
	 */
	public Node rBuild(int depth, ArrayList<double[]> input)
	{
		int axis = depth % d;

		if(input.size() == 0) {
			return null;
		} else if(input.size() == 1) {
			return new Node(axis, input.get(0));
		} else {
			double[] median = rm.median(input, axis);

			ArrayList<double[]> before = new ArrayList<double[]>();
			ArrayList<double[]> after = new ArrayList<double[]>();

			/* Everything strcitly larger than the median goes
			 * to the "right", everything including median goes to the
			 * "left".
			 */
			for(int i = 0; i < input.size(); i++) {

				int a = axis;

				/* If two coordinates are equal, we use the next one. When
				 * last coordinate is reached, we start over.
				 */
				for(int j = 0; j < d && median[a] == input.get(i)[a]; j++) {
					a = (a + 1) % d;
				}

				if(input.get(i)[a] > median[a]) {
					after.add(input.get(i));
				} else {
					before.add(input.get(i));
				}
			}

			Node here = new Node(axis, median);
			Node left, right;

			left = rBuild(depth+1, before);
			right = rBuild(depth+1, after);
			here.setLeftChild(left);
			here.setRightChild(right);

			return here;
		}
	}

	/**
	 * Public query functions, starts the recursive process of searching through the tree.
	 * @param q Query point
	 * @param root The root of the tree to search in
	 */
	public Node query(double[] q, Node root)
	{
		this.dist = new Dist(this.d);

		
		this.nodesSeen = 0;
		Node best = rQuery(q, root, null, 0, 0);

		return best;
	}

	/**
	 * Searches through a subTree.
	 * @param q Query point
	 * @param node Root of the subtree to search in
	 * @param best Best NN found so far
	 * @param depth At what depth are we at? Used to determin which axis to look at.
	 */
	private Node rQuery(double[] q, Node node, Node best, int depth, double distBest)
	{
		if(nodesSeen > maxNodes) return best;

		nodesSeen++;

		int axis = depth % this.d;
		
		double distHere, distAxis;

		if(node == null) {
			return best;
		}

		distHere = dist.euclidian(node.point, q);
		if(best == null) {
			best = node;
			distBest = distHere;
		}

		//distBest = dist.euclidian(best.point, q);

		if(distHere < distBest) {
			//node.seen = best.seen;
			best = node;
			distBest = distHere;
		}
		
		Node child = (q[axis] < node.point[axis] ? node.left : node.right);


		best = rQuery(q, child, best, ++depth, distBest);

		if(backtracking) {
			distBest = dist.euclidian(best.point, q);
			distAxis = Math.abs(node.point[axis] - best.point[axis]);

			if(distAxis < distBest) {
				child = (q[axis] >= node.point[axis] ? node.left : node.right);
				best = rQuery(q, child, best, depth, distBest);
			}
		}

		//best.seen++;
		return best;
	}
}
