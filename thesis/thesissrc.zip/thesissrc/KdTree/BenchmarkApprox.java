import java.util.*;
import org.apache.commons.cli.*;

public class BenchmarkApprox
{

	public static void main(String[] args) 
	{
		Options options = new Options();
		options.addOption("d", true, "Number of dimensions");
		options.addOption("g", false, "Use gaussian distribution instead of uniform");

		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		Integer dimensions = Integer.valueOf(cmd.getOptionValue("d"));

		System.err.println("Generating test sets..");
		/* Generate the query and corpus sets */
		ArrayList<double[]> inputList;
		ArrayList<double[]> queryList;
		
		int corpusSize = 100000;
		int querySize = 100;

		Random generator = new Random(42);
		if(cmd.hasOption("g")) {
			inputList = gaussianVectors(dimensions, corpusSize, generator);
			queryList = gaussianVectors(dimensions, querySize, generator);
		} else {
			inputList = gaussianVectors(dimensions, corpusSize, generator);
			queryList = gaussianVectors(dimensions, querySize, generator);
		}

		double[] facitDist = new double[queryList.size()];

		System.err.println("Generating facit list..");
		Dist dist = new Dist(dimensions);
		for(int i = 0; i < facitDist.length; i++) {
			facitDist[i] = dist.euclidian(queryList.get(i), inputList.get(0));
		}

		for(int j = 0; j < querySize; j++) {
			for(int i = 1; i < corpusSize; i++) {
				double tmp = dist.euclidian(queryList.get(j), inputList.get(i));
				if(tmp < facitDist[j]) {
					facitDist[j] = tmp;
				}
			}
		}


		System.err.println("Building tree");
		KdTree kdt = new KdTree(true);
		kdt.maxNodes = 500*(int)Math.ceil(Math.log(corpusSize)/Math.log(2));
		Node root = kdt.build(dimensions, inputList);
		
		System.err.println("Quering tree");
		ArrayList<double[]> found = new ArrayList<double[]>();
		long startTime, endTime, totTime = 0;
		for(double[] q : queryList) {
			startTime = System.nanoTime();
			Node best =  kdt.query(q, root);
			endTime = System.nanoTime();
			totTime += endTime-startTime;
			found.add(best.point);
		}

		double facit = 0.0, approx = 0.0;
		for(int i = 0; i < found.size(); i++) {
			double tmp = dist.euclidian(found.get(i), queryList.get(i));

			facit =+ facitDist[i];
			approx =+ tmp; 
		}

		facit = facit/facitDist.length;
		approx = approx/facitDist.length;

		System.out.println(dimensions + "\t" + facit + "\t" + approx + "\t" + (double)totTime/1000000000/querySize);
	}

	private static ArrayList<double[]> uniformVectors(int d, int n, Random generator)
	{
		int range = 100000;
		ArrayList<double[]> list = new ArrayList<double[]>();

		for(int i = 0; i < n; i++) {
			double[] p = new double[d];
			
			for(int j = 0; j < d; j++) {
				p[j] = generator.nextDouble()*range;
			}

			list.add(p);
		}

		return list;
	}
	
	private static ArrayList<double[]> gaussianVectors(int d, int n, Random generator)
	{
		double variance = 1000000.0;
		double mean = variance/2.0;
		ArrayList<double[]> list = new ArrayList<double[]>();

		for(int i = 0; i < n; i++) {
			double[] p = new double[d];
			
			for(int j = 0; j < d; j++) {
				p[j] = generator.nextGaussian()*variance + mean;
			}

			list.add(p);
		}

		return list;
	}		
}
