import java.util.*;

/**
* Implements finding the median by sorting.
*/
public class SortMedian
{
	/**
	* Takes a list of double vectores and returns the median.
	* @param input The input array with vectors
	* @param dimension The dimension of the vector the median is defined by
	* @return The median vector
	*/ 
	public double[] median(ArrayList<double[]> input, int dimension)
	{
		int medianIndex = (input.size()/2);
		return select(input, dimension, medianIndex);
	}

	/**
	* Takes a list of double vectores and returns the kth element.
	* @param input The input array with vectors
	* @param dimension The dimension of the vector the kth element is defined by
	* @param k Which element in the sorted order is desired
	* @return The kth vector
	*/ 
	public double[] select(ArrayList<double[]> input, int dimension, int k)
	{
		VectorComparator vc = new VectorComparator(dimension);
		Collections.sort(input, vc);
		return input.get(k);
	}
}	
