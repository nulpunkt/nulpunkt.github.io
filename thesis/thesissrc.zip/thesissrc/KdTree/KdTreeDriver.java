import org.apache.commons.cli.*;
import java.io.*;
import java.util.*;

/**
 * Driver for the KdTree.
 */
public class KdTreeDriver 
{
	private static int node = 0;

	public static void main(String[] args) 
	{
		Options options = new Options();
		options.addOption("h", false, "Print this");
		
		options.addOption("i", true, "Input points");
		options.addOption("q", true, "Query points");

		options.addOption("d", true, "Number of dimensions");
		
		options.addOption("n", true, "Points to be generated if no input file is given");
		options.addOption("qt", true, "Query type (uniform, n \\in {10 .. 10000})");

		options.addOption("g", false, "Print graph");
		options.addOption("result", false, "Print result");
		options.addOption("time", false, "Print dim-time");
		options.addOption("touched", false, "Print number of nodes touched");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}
		
		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java KdTreeDriver", options );
			System.exit(0);
		}
		
		boolean time = false, result = false, touched = false;
		if(cmd.hasOption("time")) {
			time = true;
		}
		if(cmd.hasOption("result")) {
			result = true;
		}
		if(cmd.hasOption("touched")) {
			touched = true;
		}
		
		Integer dimensions = Integer.valueOf(cmd.getOptionValue("d"));

		System.err.println("Dimension: " + dimensions);
		ArrayList<double[]> inputList = null;
		ArrayList<double[]> queryList = null;
		if(cmd.hasOption("i")) {
			System.err.println("Reading data");
			String inputFileName = cmd.getOptionValue("i");
			String queryFileName = cmd.getOptionValue("q");

			InputReader ir = new InputReader();
			inputList = ir.ftm(inputFileName);
			queryList = ir.ftm(queryFileName);
		} else {
			System.err.println("Benchmark mode is disabled");
			System.exit(0);
			/*
			System.err.println("Generating data");
			RandomVectorGenerator rvg = new RandomVectorGenerator();
			Integer points = Integer.valueOf(cmd.getOptionValue("n"));
			inputList = rvg.getData(points, dimensions, 1000000, false, 42);
			if(cmd.getOptionValue("qt").equals("uniform")) {
				queryList = rvg.getData(10, dimensions, 1000000, false, 42);
			} else {
				QueryVectorsGenerator qvg = new QueryVectorsGenerator();
				Integer variance = Integer.valueOf(cmd.getOptionValue("qt"));
				queryList = qvg.getData(inputList, 10, variance);
			}
			*/
		}

		/*
		for(double[] p : inputList) {
			for(double e : p) System.out.print(e + "\t");
			System.out.println();
		}

		System.exit(0);
*/
		System.err.println("Building tree");
		long startTime = System.currentTimeMillis();
		KdTree kdt = new KdTree(true);
		Node root = kdt.build(dimensions, inputList);
		long endTime = System.currentTimeMillis();

		if(cmd.hasOption("g")) {
			prettyPrint(root);
		}

		System.err.println("Querying");
		int seen = 0;
		long tottime = 0;
		Dist dist = new Dist(dimensions);
		for(double[] q : queryList) {
			startTime = System.nanoTime();
			Node best =  kdt.query(q, root);
			endTime = System.nanoTime();
			tottime += (endTime-startTime);
			if(touched) {
				seen += best.seen;
			}
			if(result) {
				System.out.println(dist.euclidian(best.point, q));
			}
		}

		if(touched) {
			System.out.println(dimensions + "\t" + (seen / queryList.size()));
		}
		if(time) {
			//System.out.println(dimensions + "	" + (double)tottime/1000000000/queryList.size());
			System.out.println((double)tottime/1000000000/queryList.size());
		}
	}

	private static int prettyPrint(Node root)
	{
		int me = ++node, left = 0, right = 0;

		if(me == 1) {
			System.out.println("digraph G {");
		}

		if(root.left != null) {
			left = prettyPrint(root.left);
			System.out.println("\t" + me + " -> " + left);
		}
		if(root.right != null) {
			right = prettyPrint(root.right);
			System.out.println("\t" + me + " -> " + right);
		}

		if(me == 1) {
			System.out.println("}");
		}
		return me;
	}
}
