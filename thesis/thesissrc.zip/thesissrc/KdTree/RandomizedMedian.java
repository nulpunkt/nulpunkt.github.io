import java.util.*;

/**
* Implements finding the median by random partitioning.
*/
public class RandomizedMedian
{
	VectorComparator vc;
	/**
	* Takes a list of double vectores and returns the median.
	* @param input The input array with vectors
	* @param dimension The dimension of the vector the median is defined by
	* @return The median vector
	*/ 
	public double[] median(ArrayList<double[]> input, int dimension)
	{
		if(input.size() == 1) {
			return input.get(0);
		}

		vc = new VectorComparator(dimension);

		if(input.size() == 2) {
			if(vc.compare(input.get(0), input.get(1)) == 1)
				return input.get(1);
			else
				return input.get(0);
		}
		int medianIndex = input.size()/2;

		return select(input, medianIndex);
	}

	/**
	* Takes a list of double vectores and returns the kth element.
	* @param input The input array with vectors
	* @param dimension The dimension of the vector the kth element is defined by
	* @param k Which element in the sorted order is desired
	* @return The kth vector
	*/ 
	public double[] select(ArrayList<double[]> input, int k)
	{
		Random generator = new Random();
		int n = input.size();
		int l = 0;
		int pivotIndex = generator.nextInt(n);
		double[] pivotElement = input.get(pivotIndex);

		ArrayList<double[]> less = new ArrayList<double[]>();
		ArrayList<double[]> greater = new ArrayList<double[]>();
		for(int i = 0; i < n; i++) {

			if(i == pivotIndex) continue;

			int c = vc.compare(input.get(i), pivotElement);
			if(c == -1) {
				l++;
				less.add(input.get(i));
			} else {
				greater.add(input.get(i));
			}
		}

		if(l == k) return pivotElement;
		else if(l > k) return select(less, k);
		else if(l < k) return select(greater, k-l-1);
		return null;
	}
}	
