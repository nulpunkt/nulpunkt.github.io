public class Probe implements Comparable<Probe>
{
	public int i, pm;
	public double dist;	

	public int compareTo(Probe p) 
	{
		if(this.dist < p.dist) return -1;
		if(this.dist > p.dist) return 1;
		else return 0;
	}

	public String toString()
	{
		return i + "\t" + dist;
	}
}
