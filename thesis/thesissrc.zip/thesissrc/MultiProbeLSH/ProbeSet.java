import java.util.LinkedList;

public class ProbeSet implements Comparable<ProbeSet>
{
	LinkedList<Integer> A;
	double score;

	public ProbeSet(LinkedList<Integer> A, double score)
	{
		this.A = A;
		this.score = score;
	}

	public int compareTo(ProbeSet p)
	{
		if(this.score < p.score) return -1;
		if(this.score > p.score) return 1;
		else return 0;
	}

	public ProbeSet copy()
	{
		LinkedList<Integer> tmp = new LinkedList<Integer>(A);
		return new ProbeSet(tmp, score);
	}
}
