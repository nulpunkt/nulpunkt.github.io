About this:
----------------------------------------
The file you have just unpacked contains
some of the source code produced while
I wrote my thesis. It is more or less
a library of near neighbor algorithms.

Requirements
----------------------------------------
 - java 1.5 or higher
 - You need to have lib/cli.jar in 
 	your path.

Instructions
----------------------------------------
Everything can be compiled by typing
"make<enter>" in a directory.

You run the algorithms by using
	java LSHDriver [options]
if you want to run lsh. Use the
-h flag for options.

Data files are binary, see 
Util/RandomVectorGenerator.java to get
an idea of how to generate them.
