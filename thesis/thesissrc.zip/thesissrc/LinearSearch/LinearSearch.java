import java.io.*;
import java.util.*;

class LinearSearch 
{
	public ArrayList<double[]> inputList;
	Dist dist;

	public void build(ArrayList<double[]> i) 
	{
		inputList = i;
		dist = new Dist(i.get(0).length);
	}

	public double[] query(double[] q)
	{
		int best = 0;
		double tmp;
		double bestDist = dist.euclidian(q,inputList.get(0));

		for(int i = 1; i < inputList.size(); i++) {
			if(inputList.get(i).length != q.length) continue;
			tmp = dist.euclidian(q,inputList.get(i));
			if(tmp < bestDist) {
				best = i;
				bestDist = tmp;
			}
		}

		return inputList.get(best);
	}

	public ArrayList<Rank> rank(double[] q)
	{
		int n = inputList.size();
		ArrayList<Rank> ranks = new ArrayList<Rank>(n);
		for(int i = 0; i < n; i++) {
			ranks.add(new Rank(i, dist.euclidian(q, inputList.get(i))));
		}

		Collections.sort(ranks);

		return ranks;
	}
}
