public class Rank implements Comparable<Rank>
{
	public double dist;
	public int index;

	public Rank(int i, double d)
	{
		this.index = i;
		this.dist = d;
	}

	public int compareTo(Rank r2)
	{
		if(r2.dist < this.dist) return 1;
		if(r2.dist > this.dist) return -1;
		return 0;
	}

	public String toString()
	{
		return ""+index;
	}
}
