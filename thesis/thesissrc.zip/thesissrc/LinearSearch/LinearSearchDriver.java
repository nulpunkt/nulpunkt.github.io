import org.apache.commons.cli.*;
import java.io.*;
import java.util.*;

class LinearSearchDriver 
{
	public static void main(String[] args) 
	{
		Options options = new Options();
		options.addOption("h", false, "Print this");
		options.addOption("i", true, "Input points");
		options.addOption("q", true, "Query points");
		options.addOption("d", true, "Dimensions");
		options.addOption("r", true, "Rank the r first nn");
		options.addOption("time", false, "Show time");
		options.addOption("result", false, "Show result");
		options.addOption("b", false, "Benchmark mode");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java LinearSearchDriver", options );
			System.exit(0);
		}
	
		ArrayList<double[]> inputList; 
		ArrayList<double[]> queryList;

		int d = 0;
		d = Integer.valueOf(cmd.getOptionValue('d'));
		if(!cmd.hasOption("b")) {
			String inputFileName = cmd.getOptionValue("i");
			String queryFileName = cmd.getOptionValue("q");

			InputReader ir = new InputReader();
			inputList = ir.ftm(inputFileName);
			queryList = ir.ftm(queryFileName);
		} else {
			/* We are in benchmark mode, create bogus data */
			RandomVectorGenerator rvg = new RandomVectorGenerator();

			inputList = rvg.getData(100000, d, 0, false, 42);
			queryList = rvg.getData(100, d, 0, false, 42);
		}

		LinearSearch ls = new LinearSearch();
		ls.build(inputList);

		if(cmd.hasOption("r")) {
			Integer points = Integer.valueOf(cmd.getOptionValue("r"));
			for(double[] q : queryList) {
				ArrayList<Rank> ranks = ls.rank(q);
				System.out.println(ranks.subList(0,points));
			}
		}
		else {
			Dist dist = new Dist(d);

			long startTime, endTime, total = 0;
			for(double[] q : queryList) {
				startTime = System.nanoTime();
				double[] point = ls.query(q);
				endTime = System.nanoTime();
				total += endTime-startTime;
				if(cmd.hasOption("result")) {
					System.out.println(dist.euclidian(point, q));
				}
			}

			if(cmd.hasOption("time")) {
				System.out.println(d + "\t" + ((double)total/(double)queryList.size())/1000000000);
			}
		}
	}
}
