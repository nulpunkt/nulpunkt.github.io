import java.util.*;
/**
* Implements the Medians of Medians algorithm.
*/
public class MedianOfMedians 
{
	/**
	* Takes a list of double vectores and returns the median.
	* @param input The input array with vectors
	* @param dimension The dimension of the vector the median is defined by
	* @return The median vector
	*/ 
	public double[] median(ArrayList<double[]> input, int dimension)
	{
		int medianIndex = (int)Math.floor(input.size()/2);
		return select(input, dimension, medianIndex);
	}

	/**
	* Takes a list of double vectores and returns the kth element.
	* @param input The input array with vectors
	* @param dimension The dimension of the vector the kth element is defined by
	* @param k Which element in the sorted order is desired
	* @return The kth vector
	*/ 
	public double[] select(ArrayList<double[]> input, int dimension, int k)
	{
		if(input.size() < 10) {
			VectorComparator vc = new VectorComparator(dimension);
			Collections.sort(input, vc);
			return input.get(k-1);
		}

		ArrayList<double[]> medians = new ArrayList<double[]>();
		ArrayList<double[]> sl = new ArrayList<double[]>();
		for(int i = 0; i < (int)Math.floor(input.size()/5); i++) {
			int low = i*5;
			int high = Math.min(i*5+5, input.size());
			sl.clear();
			for(int j = low; j < high; j++) sl.add(input.get(j));

			medians.add(select(sl, dimension, 3));
		}

		double[] M = select(medians, dimension, (int)Math.floor(input.size()/10));

		ArrayList<double[]> L1 = new ArrayList<double[]>();
		ArrayList<double[]> L2 = new ArrayList<double[]>();
		ArrayList<double[]> L3 = new ArrayList<double[]>();

		for(double[] e : input) {
			if(e[dimension] < M[dimension]) L1.add(e);
			if(e[dimension] == M[dimension]) L2.add(e);
			if(e[dimension] > M[dimension]) L3.add(e);
		}

		if(k <= L1.size()) return select(L1, dimension, k);
		else if(k > L1.size() + L2.size()) return select(L3, dimension, k-L1.size()-L2.size());
		else return M;
	}
}
