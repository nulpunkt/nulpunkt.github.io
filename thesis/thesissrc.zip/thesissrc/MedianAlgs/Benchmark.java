import org.apache.commons.cli.*;
import java.io.*;
import java.util.*;

/**
* Benchmarks the different median algorithms.
*/ 
public class Benchmark
{
	public static void main(String[] args)
	{
		long startTime, endTime;
		double[] median;

		/* Parse commandline input */
		Options options = new Options();
		options.addOption("i", true, "Input points");
		options.addOption("d", true, "Input dimensions");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}
		
		String inputFileName = cmd.getOptionValue("i");
		Integer dimensions = Integer.valueOf(cmd.getOptionValue("d"));
		
		/* Read input from file */
		InputReader ir = new InputReader(dimensions);
		ArrayList<double[]> inputList;
	   	inputList = ir.ftm(inputFileName);

		/*
		for(double[] e : inputList) {
			for(double d : e) System.out.print(d + "\t");
			System.out.println();
		}*/

		/* First class up for test is median of medians */
		MedianOfMedians mom = new MedianOfMedians();

		startTime = System.currentTimeMillis();
		for(int i = 0; i < dimensions; i++) {
			median = mom.median(inputList, i);
		}
		endTime = System.currentTimeMillis();

		System.out.print(inputList.size() + "\t" + (endTime-startTime));
	   	
		/* Testing sort median */
		SortMedian sm = new SortMedian();

		startTime = System.currentTimeMillis();
		for(int i = 0; i < dimensions; i++) {
			median = sm.median(inputList, i);
		}
		endTime = System.currentTimeMillis();

		System.out.print("\t" + (endTime-startTime));

		/* Testing median by random partitioning */
		RandomizedMedian rm = new RandomizedMedian();

		startTime = System.currentTimeMillis();
		for(int i = 0; i < dimensions; i++) {
			median = rm.median(inputList, i);
		}
		endTime = System.currentTimeMillis();

		System.out.println("\t" + (endTime-startTime));
	}
}
