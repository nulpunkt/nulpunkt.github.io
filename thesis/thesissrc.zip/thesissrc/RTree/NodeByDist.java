import java.util.*;
/**
 * A comparator to sort nodes by dist.
 * The distance is usually the minDist to a query point.
 */
public class NodeByDist implements Comparator<Node>{
    public int compare(Node n1, Node n2) {
		if(n1.dist > n2.dist) return 1;
		else if(n1.dist < n2.dist) return -1;
		else return 0;
    }
}

