import org.apache.commons.cli.*;
import java.io.*;
import java.util.*;

public class RTreeDriver 
{
	private static int node = 0;

	public static void main(String[] args) 
	{
		Options options = new Options();
		options.addOption("i", true, "Input points");
		options.addOption("q", true, "Query points");
		options.addOption("d", true, "Number of dimensions");
		options.addOption("c", true, "Outdegree of the nodes");
		options.addOption("result", false, "Show result of queries");
		options.addOption("time", false, "Show the time it took");
		options.addOption("graph", false, "Get a 2d view of the tree");
		options.addOption("h", false, "Show this");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java LSHDriver", options );
			System.exit(0);
		}

		boolean time = false, result = false;
		if(cmd.hasOption("time")) {
			time = true;
		}
		if(cmd.hasOption("result")) {
			result = true;
		}
		int c = 5;
		if(cmd.hasOption("c")) {
			c = Integer.valueOf(cmd.getOptionValue("c"));
		}
		
		String inputFileName = cmd.getOptionValue("i");
		String queryFileName = cmd.getOptionValue("q");
		Integer dimensions = Integer.valueOf(cmd.getOptionValue("d"));
		
		InputReader ir = new InputReader();
		ArrayList<double[]> inputList = ir.ftm(inputFileName);
		ArrayList<double[]> queryList = ir.ftm(queryFileName);

		RTree rt = new RTree(dimensions, c);
		Node root = rt.build(inputList);

		if(cmd.hasOption("graph")) {
			if(dimensions != 2) {
				System.err.println("Graph mode only works in 2d");
			} else {
				prettyPrint(root);
			}
		}

		long totalTime = 0;
		for(double[] q : queryList) {
			long startTime = System.nanoTime();
			Node res = rt.query(q, root);
			long endTime = System.nanoTime();
			totalTime += (endTime - startTime);

			if(result) {
				System.out.println(res.i);
			}
		}

		if(time) {
			System.out.println(dimensions + "\t" + ((double)totalTime/1000000000)/queryList.size());
		}
	}

	private static void prettyPrint(Node root)
	{
		System.out.println("\\begin{figure}[htbp]");
		System.out.println("\\setlength{\\unitlength}{0.06in}");
		System.out.println("\\centering");
		System.out.println("\\begin{picture}("+root.bb[0][1]+","+root.bb[1][1]+")");
		prettyNode(root);
		System.out.println("\\end{picture}");
		System.out.println("\\end{figure}");
	}

	private static void prettyNode(Node n)
	{
		if(n.bb == null) return;
		if(!n.leaf) {
			double x = n.bb[0][0];
			double y = n.bb[1][0];
			double l = n.bb[0][1] - n.bb[0][0];
			double h = n.bb[1][1] - n.bb[1][0];
			System.out.println("\t\\put("+x+","+y+"){\\framebox("+l+","+h+"){}}");

			for(int i = 0; i < n.children.length; i++) {
				if(n.children[i] == null) return;
				else prettyNode(n.children[i]);
			}
		} else {
			System.out.println("\t\t\\put("+n.point[0]+", "+n.point[1]+"){\\circle{0.3}}");
		}
	}
}
