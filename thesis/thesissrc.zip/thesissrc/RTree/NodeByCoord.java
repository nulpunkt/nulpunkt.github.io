import java.util.*;
/**
 * A comparator to sort nodes by Coords.
 * The distance is usually the minDist to a query point.
 */
public class NodeByCoord implements Comparator<Node>{

	String c;
	int d;
	
	/**
	 * @param d the dimension
	 * @param c can be min, max, both, center
	 */
	public NodeByCoord(int d, String c)
	{	
		this.d = d;
		this.c = c;
	}

    public int compare(Node n1, Node n2) {
		double p1 = 0.0, p2 = 0.0;
		if(c.equals("min")) {
			p1 = (n1.leaf ? n1.point[d] : n1.bb[d][0]);
			p2 = (n2.leaf ? n2.point[d] : n2.bb[d][0]);
		} else if(c.equals("max")) {
			p1 = (n1.leaf ? n1.point[d] : n1.bb[d][1]);
			p2 = (n2.leaf ? n2.point[d] : n2.bb[d][1]);
		} else if(c.equals("center")) {
			p1 = ((n1.leaf ? n1.point[d] : n1.bb[d][0] + n1.bb[d][1])/2);
			p2 = ((n2.leaf ? n2.point[d] : n2.bb[d][0] + n2.bb[d][1])/2);
		} else {
		}

		if(p1 > p2) return 1;
		else if(p1 < p2) return -1;
		else return 0;
    }
}

