import java.util.*;

/**
 * Implements a naive RTree
 */
public class RTree 
{
	int d, c, l;
	Dist dist;
	Node root;

	public RTree(int d, int c)
	{
		this.d = d;
		this.c = c;
		this.l = 0;
		root = new Node(d, c);
		dist = new Dist(d);
	}

	/**
	 * Given a number of dimensions an a list of vectors build a Tree
	 * @param d Number of dimensions
	 * @param input List of points
	 * @return The root node of the RTree
	 */
	public Node build(ArrayList<double[]> input) 
	{
		root = bulkLoad(input);

		return root;
	}

	/**
	 * Generic outer method for bulkloading
	 */
	public Node bulkLoad(ArrayList<double[]> input)
	{
		//return MOS(input);
		ArrayList<Node> nodes = new ArrayList<Node>();
		int n = input.size();
		for(int i = 0; i < n; i++) {
			nodes.add(new Node(d, c, input.get(i), i));
		}

		return TGS(nodes);
	}

	/**
	 * Build RTree from vector set, by bulk loading (Top-down Greedy Split).
	 * @param input input set
	 * @return root node of the r-tree
	 */
	public Node TGS(ArrayList<Node> input)
	{

		int n = input.size();
		if(n == 0) return null;
		if(n == 1) return input.get(0);

		Node nn = new Node(d, c);

		/* If input small enough, just patch it together */
		if(n <= c) {
			for(int i = 0; i < n; i++) {
				nn.children[i] = input.get(i);
			}

			nn.fixBoundingBox();

			return nn;
		}

		/* Else we need to split */
		int M = (int)Math.pow(c, (Math.log(n)/Math.log(c)) - 1);

		ArrayList<ArrayList<Node>> subLists = new ArrayList<ArrayList<Node>>();

		subLists.add(input);

		/* Make the sublists */
		for(int i = 0; i < c - 1; i++) {
			ArrayList<Node> in = null;
			for(int k = 0; k < subLists.size(); k++) {
				if(subLists.get(k).size() >= M*2) {
					in = subLists.get(k);
					break;
				}
			}
			
			ArrayList<Node> out = TGSSplit(in, M);
			subLists.add(out);
		}	

		for(int i = 0; i < c; i++) {
			nn.children[i] = TGS(subLists.get(i));
		}
		nn.fixBoundingBox();


		return nn;
	}

	/**
	 * The Basic TGS split step.
	 * Splits input into 2 subsets.
	 */
	private ArrayList<Node> TGSSplit(ArrayList<Node> input, int M)
	{
		//String[] orderings = {"min", "max", "center"};
		String[] orderings = {"min", "max"};
		int nsplits = (int)Math.ceil((double)input.size()/(double)M) - 1;

		int bestSplit = 0, bestDimension = 0;
		String bestOrdering = "min";
		double lowestCost = -1.0;
		/* Consider all dimensions */
		for(int j = 0; j < d; j++) {
			/* Consider all orderings */
			for(String ordering : orderings) {
				Collections.sort(input, new NodeByCoord(j, ordering));

				for(int i = 1; i <= nsplits; i++) {
					int s = i*M;

					double[][] B0 = nodeBox(input, 0, s);
					double[][] B1 = nodeBox(input, s, input.size());

					double tmp = bbIntersectAreal(B0, B1);
					
					if(lowestCost == -1.0 || tmp < lowestCost) {
						lowestCost = tmp;
						bestSplit = i*M;
						bestDimension = j;
						bestOrdering = ordering;
					}
				}

			}
		}
		Collections.sort(input, new NodeByCoord(bestDimension, bestOrdering));

		List<Node> sub = input.subList(bestSplit, input.size());
		ArrayList<Node> after = new ArrayList<Node>(sub);
		sub.clear();
		
		return after;
	}

	/**
	 * Given a list of Nodes and range, return bounding box
	 */
	private double[][] nodeBox(ArrayList<Node> points, int from, int to)
	{
		double[][] bb = new double[d][2];
		for(int i = 0; i < d; i++) {
			bb[i][0] = points.get(from).point[i];
			bb[i][1] = points.get(from).point[i];
		}
		for(int p = from; p < to; p++ ) {
			for(int i = 0; i < d; i++) {
				bb[i][0] = (bb[i][0] < points.get(p).point[i] ? bb[i][0] : points.get(p).point[i]);
				bb[i][1] = (bb[i][1] > points.get(p).point[i] ? bb[i][1] : points.get(p).point[i]);
			}
		}
		
		return bb;
	}

	/**
	 * Find the areal of the intersection of two bounding boxes
	 * @param b1 A bounding box
	 * @param b2 A bounding box
	 * @return ||b1 \ b2||
	 */
	private double bbIntersectAreal(double[][] bb1, double[][] bb2)
	{
		double p1 = 0.0, p2 = 0.0, sum = 1.0;
		for(int i = 0; i < d; i++) {
			p1 = (bb1[i][0] > bb2[i][0] ? bb1[i][0] : bb2[i][0]);
			p2 = (bb1[i][1] < bb2[i][1] ? bb1[i][1] : bb2[i][1]);
			sum *= (p2 - p1);
		}

		return sum;
	}

	/**
	 * Query the RTree with a NN query.
	 * @param q The query point
	 * @param root The root node of the tree to search in
	 */
	public Node query(double[] q, Node root)
	{

		Node best = new Node(d, c, null, -1), current = null;
		best.dist = Double.MAX_VALUE;

		PriorityQueue<Node> pq = new PriorityQueue<Node>(1, new NodeByDist());
		root.dist = minDist(q, root.bb);
		pq.add(root);

		while(pq.size() > 0) {
			current = pq.poll();	
			if(current.dist > best.dist) break;

			/* If we reache a leaf, update best if needed */
			if(current.leaf && best.dist > current.dist) {
				best = current;
			}
			/* Else expand the search */
			if(!current.leaf) {
				for(int i = 0; i < c && current.children[i] != null; i++) {
					if(current.children[i].leaf) {
						current.children[i].dist = dist.euclidian(q, current.children[i].point);
					} else {
						current.children[i].dist = minDist(q, current.children[i].bb);
					}
					if(current.children[i].dist < best.dist) {
						pq.add(current.children[i]);
					}
				}
			}

			/* Note that we do not remove nodes in the pq with dist > best dist. It was faster to leave them, compared to weeding them out */
		}

		return best;
	}

	/**
	 * Returns the min dist between a point q and a bounding box bb
	 */
	private double minDist(double[] q, double[][] bb)
	{
		double[] bounds = r(q, bb);

		return dist.euclidian(q, bounds);
	}

	/**
	 * Make the r array.
	 * dist(r, q) is the minDist between q and bb.
	 * @param q Query point
	 * @param bb Boundbox of the rect in question
	 */
	private double[] r (double[] q, double[][] bb) {
		double[] r = new double[d];

		for(int i = 0; i < d; i++) {
			if(q[i] < bb[i][0]) {
				r[i] = bb[i][0];
			} else if(q[i] > bb[i][1]) {
				r[i] = bb[i][1];
			} else {
				r[i] = q[i];
			}
		}

		return r;
	}
}
