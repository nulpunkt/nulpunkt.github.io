import java.util.*;
/**
 * A comparator to sort vectors by dimension.
 */
public class VectorByDimension implements Comparator<double[]>{

	int d;

	/* We need to know on which dimension we sort */
	public VectorByDimension(int d)
	{
		this.d = d;
	}

    public int compare(double[] v1, double[] v2) {
		if(v1[d] > v2[d]) return 1;
		else if(v1[d] < v2[d]) return -1;
		else return 0;
    }
}

