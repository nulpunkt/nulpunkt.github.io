import java.util.*;

/**
 * Implements a node for the Rtree
 */
public class Node {
	/* If the node is a leaf, it only contains a point */
	boolean leaf;
	double[] point;

	/* If not a leaf, it has a set of children, as well as a bounding box. */
	Node[] children;
	double[][] bb;

	/* Used when calculating the minDist from rect to query point */
	double dist;

	int d, c, i;

	/**
	 *  Constructs a new node, with a empty bounding box and no children
	 */
	public Node(int d, int c)
	{
		this.d = d;
		this.c = c;
		this.leaf = false;

		bb = new double[d][2];
		for(int i = 0; i < d; i++) {
			bb[i][0] = -1.0;
			bb[i][1] = -1.0;
		}
		children = new Node[c];
	}

	/**
	 * Creates a new leaf, no children, and a 0 size bb
	 */
	public Node(int d, int c, double[] p) {
		this.d = d;
		this.c = c;

		this.leaf = true;
		this.point = p;
	}

	public Node(int d, int c, double[] p, int i) {
		this(d, c, p);
		this.i = i;
	}



	/**
	 * Something has happend, we need to update the bounding box
	 */
	public void fixBoundingBox()
	{
		/* Fix bb */
		for(int i = 0; i < d; i++) {
			if(children[0].leaf) {
				bb[i][0] = children[0].point[i];
				bb[i][1] = children[0].point[i];
			} else {
				bb[i][0] = children[0].bb[i][0];
				bb[i][1] = children[0].bb[i][1];
			}
		}
		for(Node c : children) {
			if(c == null) break;
			for(int i = 0; i < d; i++) {
				if(c.leaf) {
					bb[i][0] = (bb[i][0] < c.point[i] ? bb[i][0] : c.point[i]);
					bb[i][1] = (bb[i][1] > c.point[i] ? bb[i][1] : c.point[i]);
				} else {
					bb[i][0] = (bb[i][0] < c.bb[i][0] ? bb[i][0] : c.bb[i][0]);
					bb[i][1] = (bb[i][1] > c.bb[i][1] ? bb[i][1] : c.bb[i][1]);
				}
			}
		}
	}

}
