import java.util.*;

public class Searcher implements Runnable 
{
	ArrayList<double[]> input;
	double[] query;
	int from, to, result, n;
	double minDist;

	Dist dist;

	public Searcher(ArrayList<double[]> input, double[] query, int from, int to)
	{
		this.input = input;
		this.query = query;
		this.from = from;
		int n = input.size();
		this.to = (to > n ? n : to);
	}

	public void run()
	{
		this.dist = new Dist(query.length);
		double tmp;
		double best = dist.euclidian(query, input.get(from));
		result = from;
		for(int i = from+1; i < to; i++) {
			tmp = dist.euclidian(query, input.get(i));
			if(tmp < best) {
				best = tmp;
				result = i;
			}
		}

		minDist = best;
	}
}
