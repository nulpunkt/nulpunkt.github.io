import java.util.*;
import java.io.*;
import org.apache.commons.cli.*;

/**
 * From Zipf distribution
*/

public class ZipfVectorGenerator
{
	public static void main(String[] args)
	{
		/* Parse commandline input */
		Options options = new Options();
		options.addOption("n", true, "Number of points");
		options.addOption("o", true, "Output file");
		options.addOption("d", true, "Number of dimensions");
		options.addOption("size", true, "Numeric space");
		options.addOption("skew", true, "How skew");
		options.addOption("h", false, "Show help");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java RandomVectorGenerator", options );
			System.exit(0);
		}
		
		Integer points = Integer.valueOf(cmd.getOptionValue("n"));
		String outputFile = cmd.getOptionValue("o");
		Integer dimensions = Integer.valueOf(cmd.getOptionValue("d"));
		Integer size = 10;
		if(cmd.hasOption("size")) {
			size = Integer.valueOf(cmd.getOptionValue("size"));
		}
		Integer skew = 1;
		if(cmd.hasOption("skew")) {
			skew = Integer.valueOf(cmd.getOptionValue("skew"));
		}

		/* Generate the points */
		ZipfGenerator zipf = new ZipfGenerator(size, skew);

		try { 
			BufferedWriter out = new BufferedWriter(new FileWriter(outputFile));
			for(int i = 0; i < points; i++) {
				for(int j = 0; j < dimensions; j++) {
					out.write(zipf.next() + "\t");
				}
				out.newLine();
			}
			out.close(); 
		}
		catch (IOException e) {
			System.err.println("Der opstod en fejl ved skrivning til fil");
		}


	}
}

/**
 * Big thanks to Hyunsik Choi
 */
class ZipfGenerator {
	private Random rnd = new Random();
	private int size;
	private double skew;
	private double bottom = 0;

	public ZipfGenerator(int size, double skew) {
		this.size = size;
		this.skew = skew;

		for(int i=1;i<size; i++) {
			this.bottom += (1/Math.pow(i, this.skew));
		}
	}

	/**
	 * the next() method returns an rank id. 
	 * The frequency of returned rank ids follows Zipf distribution.
	 */
	public int next() {
		int rank;
		double friquency = 0;
		double dice;

		rank = rnd.nextInt(size);
		friquency = (1.0d / Math.pow(rank, this.skew)) / this.bottom;
		dice = rnd.nextDouble();

		while(!(dice < friquency)) {
			rank = rnd.nextInt(size);
			friquency = (1.0d / Math.pow(rank, this.skew)) / this.bottom;
			dice = rnd.nextDouble();
		}

		return rank;
	}

	/** 
	 * This method returns a probability that the given rank occurs.
	 */
	public double getProbability(int rank) {
		return (1.0d / Math.pow(rank, this.skew)) / this.bottom;
	}
}
