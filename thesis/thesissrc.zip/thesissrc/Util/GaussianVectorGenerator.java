import java.util.*;
import java.io.*;
import org.apache.commons.cli.*;

/**
* Generates a set of random vectors, with entries between 0 and 1
*/

public class GaussianVectorGenerator
{
	public static void main(String[] args)
	{
		/* Parse commandline input */
		Options options = new Options();
		options.addOption("n", true, "Number of points");
		options.addOption("o", true, "Output file");
		options.addOption("d", true, "Number of dimensions");
		options.addOption("h", false, "Show help");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java GaussianVectorGenerator", options );
			System.exit(0);
		}
		
		Integer points = Integer.valueOf(cmd.getOptionValue("n"));
		String outputFile = cmd.getOptionValue("o");
		Integer dimensions = Integer.valueOf(cmd.getOptionValue("d"));

		/* Generate the points */
		Random generator = new Random();

		try { 
			BufferedWriter out = new BufferedWriter(new FileWriter(outputFile));
			for(int i = 0; i < points; i++) {
				for(int j = 0; j < dimensions; j++) {
					out.write(generator.nextGaussian() + "\t");
				}
				out.newLine();
			}
			out.close(); 
		}
		catch (IOException e) {
			System.err.println("Der opstod en fejl ved skrivning til fil");
		}
	}
}

