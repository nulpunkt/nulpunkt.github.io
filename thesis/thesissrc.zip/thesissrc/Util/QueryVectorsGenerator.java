import java.util.*;
import java.io.*;
import org.apache.commons.cli.*;

/**
* Generates a set of query vectors
*/

public class QueryVectorsGenerator
{
	public static void main(String[] args)
	{
		/* Parse commandline input */
		Options options = new Options();
		options.addOption("n", true, "Number of points");
		options.addOption("d", true, "#Dimensions");
		options.addOption("v", true, "Distance to data point");
		options.addOption("i", true, "Input file");
		options.addOption("o", true, "Output file");
		options.addOption("h", false, "Show help");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java RandomVectorGenerator", options );
			System.exit(0);
		}
		
		Integer points = Integer.valueOf(cmd.getOptionValue("n"));
		int d = Integer.valueOf(cmd.getOptionValue("d"));
		Integer variance = Integer.valueOf(cmd.getOptionValue("v"));
		String outputFile = cmd.getOptionValue("o");
		String inputFile = cmd.getOptionValue("i");

		/* Read dataset */
		InputReader ir = new InputReader();
		ArrayList<double[]> inputList = ir.ftm(inputFile);

		/* Generate the points */
		QueryVectorsGenerator qvg = new QueryVectorsGenerator();
		ArrayList<double[]> QueryPoints = qvg.getData(inputList, points, d, variance);
		
		try {
			DataOutputStream out = new DataOutputStream(
					new BufferedOutputStream(
						new FileOutputStream(outputFile)
						)
					);
			out.writeInt(points);
			out.writeInt(d);

			for(double[] p : QueryPoints) {
				for(double e : p) {
					out.writeDouble(e);
				}
			}
			out.close(); 
		}
		catch (IOException e) {
			System.err.println("Der opstod en fejl ved skrivning til fil");
		}
	}
	
	ArrayList<double[]> getData(ArrayList<double[]> input, int points, int d, double variance)
	{
		double[] a, b;
		b = new double[d];
		double sum;

		Random generator = new Random(42);
		int n = input.size();

		ArrayList<double[]> queries = new ArrayList<double[]>();

		for(int i = 0; i < points; i++) {
			a = input.get(generator.nextInt(n));
			sum = 0;
			for(int j = 0; j < d; j++) {
				b[j] = generator.nextDouble();
				sum += b[j]*b[j];
			}
			
			sum = Math.sqrt(sum);

			for(int j = 0; j < d; j++) {
				b[j] /= sum;
				b[j] *= variance;

				a[j] += b[j];
			}
			queries.add(a);
		}

		return queries;
	}
}

