class Median
{
	public int randomized(int d, int left, int right, ArrayList<double[]> input)
	{
		
	}

