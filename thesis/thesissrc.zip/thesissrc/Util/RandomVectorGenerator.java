import java.util.*;
import java.io.*;
import org.apache.commons.cli.*;

/**
* Generates a set of uniform random vectors
*/

public class RandomVectorGenerator
{
	public static void main(String[] args)
	{
		/* Parse commandline input */
		Options options = new Options();
		options.addOption("n", true, "Number of points");
		options.addOption("o", true, "Output file");
		options.addOption("d", true, "Number of dimensions");
		options.addOption("r", true, "Range [0,r]");
		options.addOption("h", false, "Show help");
		options.addOption("u", false, "Generated unit-length vectors");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java RandomVectorGenerator", options );
			System.exit(0);
		}
		
		Integer points = Integer.valueOf(cmd.getOptionValue("n"));
		String outputFile = cmd.getOptionValue("o");
		Integer dimensions = Integer.valueOf(cmd.getOptionValue("d"));
		Integer range = 0;
		if(cmd.hasOption("r"))
			range = Integer.valueOf(cmd.getOptionValue("r"));
		boolean unitlength = cmd.hasOption("u");

		/* Generate the points */
		Random generator = new Random();

		double[] a = new double[dimensions];
		double length = 0.0;

		try {
			DataOutputStream out = new DataOutputStream(
										new BufferedOutputStream(
											new FileOutputStream(outputFile)
											)
									);
			out.writeInt(points);
			out.writeInt(dimensions);
			for(int i = 0; i < points; i++) {
				length = 0.0;
				for(int j = 0; j < dimensions; j++) {
				   	if(range == 0) {
						if(unitlength) {
							a[j] = generator.nextDouble();
						} else {
							out.writeDouble(generator.nextDouble());
						}
					} else {
						if(unitlength) {
							a[j] = generator.nextDouble()*range;
						} else {
							out.writeDouble(generator.nextDouble()*range);
						}
					}
					if(unitlength) {
						length += a[j] * a[j];
					}
				}
				if(unitlength) {
					length = Math.sqrt(length);
					for(int j = 0; j < dimensions; j++) {
						out.writeDouble(a[j]/length);
					}
				}
			}
			out.close(); 
		} catch (IOException e) {
			System.err.println("Der opstod en fejl ved skrivning til fil");
		}
	}

	ArrayList<double[]> getData(int points, int dimensions, int range, boolean unitlength, int seed)
	{
		ArrayList<double[]> data = new ArrayList<double[]>(points);
		double[] a;
		double length;
		Random generator = new Random(seed);
		for(int i = 0; i < points; i++) {
			a = new double[dimensions];
			length = 0.0;
			for(int j = 0; j < dimensions; j++) {
				if(range == 0) {
					a[j] = generator.nextDouble();
				} else {
					a[j] = generator.nextDouble()*range;
				}
				if(unitlength) {
					length += a[j] * a[j];
				}
			}
			if(unitlength) {
				length = Math.sqrt(length);
				for(int j = 0; j < dimensions; j++) {
					a[j] = a[j]/length;
				}
			}

			data.add(a);

		}

		return data;
	}
}

