import java.util.*;

public class VectorComparator implements Comparator<double[]>
{
	int d;
	public VectorComparator(int d)
	{
		this.d = d;
	}

	public int compare(double[] v1, double[] v2)
	{
		int a = d;

		/* If two coordinates are equal, we use the next one. When
		 * last coordinate is reached, we start over.
		 */
		for(int i = 0; i < v1.length && v1[a] == v2[a]; i++) {
			a = (a + 1) % v1.length;
		}

		if(v1[a] < v2[a]) return -1;
		if(v1[a] > v2[a]) return 1;
		return 0;
	}
}
