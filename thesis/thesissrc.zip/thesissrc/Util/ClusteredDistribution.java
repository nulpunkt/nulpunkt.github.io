import org.apache.commons.cli.*;
import java.io.*;
import java.util.*;

public class ClusteredDistribution
{
	public static void main(String[] args)
	{
		Options options = new Options();
		options.addOption("n", true, "#points pr cluster");
		options.addOption("d", true, "#dimensions");
		options.addOption("c", true, "#clusters");
		options.addOption("s", true, "scalar");
		options.addOption("i", true, "Dataset file");
		options.addOption("u", false, "Unit-length vectors");
		options.addOption("h", false, "Show this");

		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}

		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java LumpyDistribution", options );
			System.exit(0);
		}
		int n=1, d=1, c=1, s=1;
		String ifile = null, qfile = null;
		try {
			n = Integer.valueOf(cmd.getOptionValue("n"));
			d = Integer.valueOf(cmd.getOptionValue("d"));
			c = Integer.valueOf(cmd.getOptionValue("c"));
			ifile = cmd.getOptionValue("i");

		} catch(Exception e) {
			System.err.println("Options n, d, c, i, q are not optional, see -h");
			System.exit(-1);
		}

		if(cmd.hasOption("s")) {
			s = Integer.valueOf(cmd.getOptionValue("s"));
		}
		boolean u = false;

		if(cmd.hasOption("u")) {
			u = true;
		}

		ArrayList<double[]> data = getData(n, d, c, s, u);
		
		Random r = new Random(42);

		double[] nul = new double[d];
		for(int i = 0; i < d; i++) nul[i] = 0;

		/* Write 10 random query points to file. */
		try {
			DataOutputStream out = new DataOutputStream(
					new BufferedOutputStream(
						new FileOutputStream(ifile)
						)
					);
			out.writeInt(n*c);
			out.writeInt(d);
			for(double[] p : data)
				for(double e : p) out.writeDouble(e);

			out.close(); 
		} catch (IOException e) {
			System.err.println("Der opstod en fejl ved skrivning til fil");
		}
	}

	public static ArrayList<double[]> getData(int n, int d, int l, int s, boolean u)
	{
		ArrayList<double[]> data = new ArrayList<double[]>(n*l);

		Random r = new Random(42);
		double sum;

		for(int i = 0; i < l; i++) {
			double[] median = new double[d];
			for(int k = 0; k < d; k++) {
				median[k] = r.nextDouble() * s;
			}
			for(int j = 0; j < n; j++) {
				double[] p = new double[d];
				sum = 0;
				for(int k = 0; k < d; k++) {
					p[k] = r.nextGaussian() + median[k];
					sum += p[k]*p[k];
				}
				if(u) {
					sum = Math.sqrt(sum);
					for(int k = 0; k < d; k++) {
						p[k] /= sum;
					}
				}
				data.add(p);
			}
		}

		return data;

	}
}
