import java.util.*;

class VectorSort
{
	public ArrayList<double[]> sort(int d, ArrayList<double[]> input)
	{
		return qsort(input, 0, input.size()-1, d);
	}

	private ArrayList<double[]> qsort(ArrayList<double[]> input, int left, int right, int d)
	{
		Random r = new Random();
		if(right > left) {
			int pivotIndex = left + r.nextInt(right-left);
			int pivotNewIndex = partition(input, left, right, pivotIndex, d);
			qsort(input, left, pivotNewIndex-1, d);
			qsort(input, pivotNewIndex+1, right, d);
		}

		return input;
	}

	private int partition(ArrayList<double[]> input, int left, int right, int pivotIndex, int d)
	{
		double[] pivotValue = input.get(pivotIndex);
		swap(input, pivotIndex, right);
		int storeIndex = left;

		for(int i = left; i < right; i++) {
			if(input.get(i)[d] <= pivotValue[d]) {
				swap(input, i, storeIndex);
				storeIndex++;
			}
		}

		swap(input, storeIndex, right);

		return storeIndex;
	}

	private void swap(ArrayList<double[]> input, int i, int j)
	{
		double[] tmp = input.get(i);
		input.set(i, input.get(j));
		input.set(j, tmp);
	}
}
