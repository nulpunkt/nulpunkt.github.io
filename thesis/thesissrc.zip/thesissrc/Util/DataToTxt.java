import java.util.*;

public class DataToTxt 
{
	public static void main(String[] args)
	{
		InputReader ir = new InputReader();

		ArrayList<double[]> data = ir.ftm(args[0]);

		for(double[] p : data) {
			for(double e : p) System.out.print(e + "\t");
			System.out.println();
		}


	}
}
