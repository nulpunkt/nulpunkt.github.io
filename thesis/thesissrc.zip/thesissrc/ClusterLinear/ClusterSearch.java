import java.io.*;
import java.util.*;

class ClusterSearch 
{
	public ArrayList<double[]> inputList;
	Dist dist;
	int d, c, n;

	double[][] mean;

	public ClusterSearch(int d, int c, int n) 
	{
		this.d = d;
		this.c = c;
		this.n = n;

		mean = new double[c][d];
	}

	public void build(ArrayList<double[]> input) 
	{
		this.inputList = input;
		dist = new Dist(d);

		double sum;
		double[] tmp;
		for(int i = 0; i < c; i++) {
			for(int k = 0; k < d; k++) {
				sum = 0;
				for(int j = 0; j < n; j++) {
					tmp = inputList.get(i*n + j);
					sum += tmp[k];
				}
				mean[i][k] = sum/n;
			}
		}
	}

	public int query(double[] q)
	{
		int bestCluster = 0;
		double tmp;
		double bestDist = dist.euclidian(q, mean[0]);

		/* Find most promissing cluster */
		for(int i = 1; i < c; i++) {
			tmp = dist.euclidian(q, mean[i]);
			if(tmp < bestDist) {
				bestDist = tmp;
				bestCluster = i;
			}
		}

		int bestPoint = bestCluster*n;
		bestDist = dist.euclidian(q, inputList.get(bestPoint));
		/* Search most promissing cluster */
		for(int i = 1; i < n; i++) {
			tmp = dist.euclidian(q, inputList.get(bestCluster*n + i));
			if(tmp < bestDist) {
				bestDist = tmp;
				bestPoint = bestCluster*n + i;
			}
		}

		return bestPoint;
	}
}
