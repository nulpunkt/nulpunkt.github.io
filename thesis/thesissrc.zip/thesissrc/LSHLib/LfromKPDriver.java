public class LfromKPDriver
{
	public static void main(String[] args)
	{
		int k = Integer.valueOf(args[0]);
		double p = Double.valueOf(args[1]);
		double w = Double.valueOf(args[2]);
		double R = Double.valueOf(args[3]);

		System.out.println(LSHMath.LfromKP(k, p, w, R));
	}
}

