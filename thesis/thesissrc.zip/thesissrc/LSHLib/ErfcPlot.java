public class ErfcPlot
{
	public static void main(String[] args)
	{
		for(double x = 0.1; x < 10; x += 0.1) {
			System.out.println(x + "\t" + LSHMath.erfc(x));
		}
	}
}
