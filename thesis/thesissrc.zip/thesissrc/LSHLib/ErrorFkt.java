public class ErrorFkt
{
	public static double M_SQRT2 = Math.sqrt(2);
	public static double M_2_SQRTPI = 2 / Math.sqrt(Math.PI);
	public static void main(String[] args)
	{
		double w = 8.0;
		double c = 5.0;
		double x = w/c;
		double p1 = M_2_SQRTPI / M_SQRT2;
		double p2 = x * ( 1 - Math.exp(-1*Math.sqrt(x) / 2));

		System.out.println("p1: " + p1 + ", p2: " + p2);
	}
}
