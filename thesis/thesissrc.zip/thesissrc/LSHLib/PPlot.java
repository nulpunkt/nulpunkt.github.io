public class PPlot
{
	public static void main(String[] args)
	{
		double w  = Double.valueOf(args[0]);
		double c  = Double.valueOf(args[1]);

		System.out.println(LSHMath.P(w, c));
	}
}
