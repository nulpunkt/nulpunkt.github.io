public class LSHMath
{
	public static double M_SQRT2 = Math.sqrt(2);
	public static double M_2_SQRTPI = 2 / Math.sqrt(Math.PI);

	/**
	 * Computation of the complementary error function erfc(x).
	 *
	 * The algorithm is based on a Chebyshev fit as denoted in
	 * Numerical Recipes 2nd ed. on p. 214 (W.H.Press et al.).
	 *
	 * The fractional error is always less than 1.2e-7.
	 *
	 * The parameters of the Chebyshev fit
	 */

	public static double erfc(double x)
	{
		double a1 = -1.26551223, a2 = 1.00002368,
			   a3 = 0.37409196, a4 = 0.09678418,
			   a5 = -0.18628806, a6 = 0.27886807,
			   a7 = -1.13520398, a8 = 1.48851587,
			   a9 = -0.82215223, a10 = 0.17087277;
		
		double v = 1; // The return value
		double z = Math.abs(x);
		
		if (z == 0) return v; // erfc(0)=1
		double t = 1/(1+0.5*z);
		v = t*Math.exp((-z*z) +a1+t*(a2+t*(a3+t*(a4+t*(a5+t*(a6+
									t*(a7+t*(a8+t*(a9+t*a10)))))))));
		if (x < 0) v = 2-v;	  // erfc(-x)=2-erfc(x)
		return v;
	}

	/**
	 * The function p from the paper (probability of collision of 2
	 * points for 1 LSH function).
	 */
	public static double P(double w, double c)
	{
		double x = w/c;
		double res = 1 - erfc(x / M_SQRT2) - M_2_SQRTPI / M_SQRT2 / x * ( 1 - Math.exp(-1*Math.sqrt(x) / 2));

		return res;
	}

	/**
	 * Computes the parameter L of the algorithm, given the parameter
	 * k and the desired success probability
	 * successProbability. Functions g are considered all independent
	 * (original scheme).
	 */
	public static Integer LfromKP(Integer k, double successProbability, double w, double R){
		double L = Math.ceil(Math.log(1 - successProbability) / Math.log(1 - Math.pow(P(w, R), k)));

		return ((Double)L).intValue();
	}


}
