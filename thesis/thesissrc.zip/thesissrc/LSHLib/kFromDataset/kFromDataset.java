import org.apache.commons.cli.*;
import java.io.*;
import java.util.*;

class kFromDataset
{
	public static void main(String[] args) 
	{
		Options options = new Options();
		options.addOption("i", true, "Input points");
		options.addOption("q", true, "Query points");
		options.addOption("w", true, "w param for hash fkt");
		options.addOption("r", true, "r param for hash fkt");
		options.addOption("h", false, "Show this");
		
		CommandLine cmd = null;
		try {
			CommandLineParser parser = new PosixParser();
			cmd = parser.parse( options, args);
		} catch(Exception e) {
			System.err.print(e);
		}
		
		if(cmd.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("java kFromDataset", options );
			System.exit(0);
		}
		
		double w = 4.0, r = 1.0;
		if(cmd.hasOption("w")) {
			w = Double.valueOf(cmd.getOptionValue("w"));
		}
		if(cmd.hasOption("r")) {
			r = Double.valueOf(cmd.getOptionValue("r"));
		}
		String inputFileName = cmd.getOptionValue("i");
		String queryFileName = cmd.getOptionValue("q");
		
		InputReader ir = new InputReader();
		ArrayList<double[]> queryList = ir.ftm(queryFileName);
		int nQueryPoints = ir.points;
		ArrayList<double[]> inputList = ir.ftm(inputFileName);
		int nDataPoints = ir.points;

		double[][] distance = new double[nDataPoints][nQueryPoints];

		Dist dist = new Dist(ir.dimensions);
		double[] q = queryList.get(0);
		for(int i = 0; i < nDataPoints; i++) {
			double[] p = inputList.get(i);
			for(int j = 0; j < nQueryPoints; j++)
				distance[i][j] = dist.euclidian(p, queryList.get(j));
		}

		for(int k = 2; k < 100; k++) {
			double collisions = 0.0;
			for(int i = 0; i < nDataPoints; i++) {
				for(int j = 0; j < nQueryPoints; j++)
					collisions += Math.pow(LSHMath.P(w, distance[i][j]), k);
			}
			collisions /= nQueryPoints;
			int L = LSHMath.LfromKP(k, 0.9, w, r);
			System.out.println(k + "\t" + L + "\t" + (ir.dimensions*k*L + ir.dimensions*L*collisions));
			//System.out.println(k + "\t" + L + "\t" + (L*collisions));
		}
	}
}
